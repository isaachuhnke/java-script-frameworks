java-script-frameworks

Tutorials and materials for learning a java-script framework

Exercício de jQuery

Torná-lo responsivo, para todas as mídias.

Colocar o menu na vertical.

Mudar o cód jQuery para:

• Trocar a cor do texto dos links para azul;

• Mexer na animação.

• Postar no Github.
